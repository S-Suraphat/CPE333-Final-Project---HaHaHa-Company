<?php
$I = new AcceptanceTester($scenario);
$I->wantTo('Test ID : 2');
$I->amOnPage('/Shop.html');
$I->seeCurrentUrlEquals('/HaHaHa/Shop.html');

$I->wait(1);
$I->click('.//input[@id="shopAdd2"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd6"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd4"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd2"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd2"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd6"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd6"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd6"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd6"]');
$I->wait(1);
$I->click('.//a[@id="clickCartDropDown2"]');
$I->wait(1);
$I->click('.//a[@id="clickShowCart"]');
$I->wait(1);

//pop-up display cart list
$I->wait(1);
$I->seeInPopup('2 (3)');
$I->seeInPopup('6 (5)');
$I->seeInPopup('4 (1)');
$I->wait(1);
$I->acceptPopup();
$I->wait(1);