<?php
$I = new AcceptanceTester($scenario);
$I->wantTo('Test ID : 1');
$I->amOnPage('/Shop.html');
$I->seeCurrentUrlEquals('/HaHaHa/Shop.html');

$I->wait(1);
$I->click('.//input[@id="shopAdd1"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd3"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd5"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd7"]');
$I->wait(1);
$I->click('.//input[@id="shopAdd9"]');
$I->wait(1);
$I->click('.//a[@id="clickCartDropDown2"]');
$I->wait(1);
$I->click('.//a[@id="clickShowCart"]');
$I->wait(1);

//pop-up display cart list
$I->wait(1);
$I->seeInPopup('1 (1)');
$I->seeInPopup('3 (1)');
$I->seeInPopup('5 (1)');
$I->seeInPopup('7 (1)');
$I->seeInPopup('9 (1)');
$I->wait(1);
$I->acceptPopup();
$I->wait(1);